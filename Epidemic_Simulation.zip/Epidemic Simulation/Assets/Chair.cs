using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chair : Claimable
{
	public int roomId;
}
