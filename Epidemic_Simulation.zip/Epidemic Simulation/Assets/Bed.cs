using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bed : MonoBehaviour
{
    public int roomId;
    public Transform sleepPosition;
    public AgentType agentType;
}
