using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Represents a task instruction that an <see cref="Agent"/> can carry out.
/// Also, they really need to add union types...
/// </summary>
public abstract class TaskInstruction
{
	
}
