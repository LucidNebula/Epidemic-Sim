﻿public enum Tasks
{
	GoToBed,
	SleepUntilNextMorning,
	GoHome,
	GoWork,
	IdleWork,
	Lunch,
	LivingRoom
}
